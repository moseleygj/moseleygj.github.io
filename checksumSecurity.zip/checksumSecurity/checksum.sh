#!/bin/bash

# List of target files and directories
paths=(
  /boot/vmlinuz-*
  /boot/initramfs-*
  /boot/efi/
  /etc/default/grub
  /etc/fstab
  /boot/grub2/grub.cfg
  /etc/passwd
  /etc/shadow
  /etc/group
  /etc/gshadow
  /etc/sudoers
  /etc/hostname
  /etc/hosts
  /etc/resolv.conf
  /etc/systemd/
  /etc/pam.d/
  #/bin/
  #/sbin/
  #/usr/
  /usr/bin/
  /usr/sbin/

  /lib/modules/
  #/lib64/
  #/var/lib/rpm/
  /etc/sysconfig/
  #/var/log/
  #/tmp/
  #/var/tmp/
)

# Function to check and hash
for path in "${paths[@]}"; do
  if [ -f "$path" ] && [ -s "$path" ]; then
    md5sum "$path"
  elif [ -d "$path" ]; then
    find "$path" -type f -size +0c \
      ! -name "*.lock" \
      ! -name "*.pid" \
      ! -path "*/flatpak-cache-*" \
      ! -path "*/cache/*" \
      ! -path "*/tmp/*" \
      -exec md5sum {} + 2>/dev/null
  fi
done
