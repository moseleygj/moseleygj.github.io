#Get a list of files to monitor
#==================
##Boot and kernel
#==================
"""
/boot/vmlinuz-*	Linux kernel image
/boot/initramfs-*	Initial RAM filesystem (used during boot)
/boot/efi/	EFI system partition (for UEFI systems)
/etc/default/grub	GRUB config template
/etc/fstab	Filesystem mount points and options
/boot/grub2/grub.cfg (or /boot/efi/EFI/fedora/grub.cfg)	GRUB bootloader config – do not edit directly! Use grub2-mkconfig instead

"""
#==========================
#System Configuration files:
#==========================
"""
/etc/passwd	User account definitions
/etc/shadow	Encrypted user passwords
/etc/group	Group account definitions
/etc/gshadow	Secure group passwords
/etc/sudoers	sudo permissions (use visudo to edit safely)
/etc/hostname	System hostname
/etc/hosts	Static hostname resolution
/etc/resolv.conf	DNS settings (often managed by NetworkManager)
/etc/systemd/	systemd service configurations
/etc/pam.d/	Pluggable Authentication Modules – controls logins and auth
"""

#==========================
#Critical Directories – Do Not Modify Contents Manually:
#==========================
"""
/bin/	Essential user binaries
/sbin/	System binaries
/usr/	Secondary system files and libraries
/lib/, /lib64/	Shared libraries
/var/lib/rpm/	RPM database – corrupting this can break package management
/etc/sysconfig/	System service and network settings
"""

#==========================
#Logs:
#==========================
"""
/var/log/	System logs – safe to read, risky to delete or modify blindly
/tmp/, /var/tmp/	Temporary files – sometimes cleaned automatically
"""


#harsh the files
#put them into a list
#check list for changes
import os
import subprocess

myBaseline = []  # Declare global upfront
os.system("clear")

def start_baseline():
    #os.system("clear")
    print("🔄 Creating baseline...")

    # Run the checksum.sh script
    subprocess.run("sudo ./checksum.sh > baseline.txt", shell=True)

    # Read and store the baseline
    with open("baseline.txt", "r") as file:
        content = file.read()
        global myBaseline
        myBaseline = content.splitlines()

    print("✅ Baseline created and loaded into memory.")

def start_verify():
   # os.system("clear")
    print("🔍 Verifying system...")
    subprocess.run("sudo ./checksum.sh > verify.txt", shell=True)

    with open("verify.txt", "r") as file:
        content = file.read()
        list_current = content.splitlines()

    non_common_items = list(set(myBaseline) ^ set(list_current))

    print("⚠️\t\t HASH  \t\t  Modified files")
    print("---------------------------------------------------")
    for item in non_common_items:
        print(item)
        exit

def menu():
    while True:
        print("\n===== System Integrity Menu =====")
        print("1. 📈  Create Baseline")
        print("2. 🔍  Verify System")
        print("3. ❌  Exit")
        choice = input("Enter your choice: ").strip()

        if choice == "1":
            start_baseline()
        elif choice == "2":
            if not myBaseline:
                print("⚠️ Please create a baseline first.")
            else:
                start_verify()
        elif choice == "3":
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")

if __name__ == "__main__":
    menu()
